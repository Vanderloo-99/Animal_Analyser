package com.example.databasetest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class Collection extends AppCompatActivity {

    public static final String ANIMAL_CHOSEN = "com.example.databasetest.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection);


        for(int i = 1; i <= 10; i++) {
            String buttonID = "animal" + i;
            testLocks(buttonID);
        }

    }
    public void onCameraPress(View view){
        Intent intent = new Intent(this, CameraAi.class);
        startActivity(intent);
    }

    public void OnAnimalPress(View view){
        if((String)view.getTag() != "locked") {
            Intent intent = new Intent(this, AnimalInfo.class);
            String message = (String) view.getTag();
            TextView textView = findViewById(R.id.text);
            textView.setText(message);
            intent.putExtra(ANIMAL_CHOSEN, message);
            startActivity(intent);
        }
    }

    public void testLocks(String buttonID){
        int count = 0;
        int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
        ImageButton button = ((ImageButton)findViewById(resID));
        String animal = (String)button.getTag();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        String user = pref.getString("USERNAME", null);

        String AnimalID = getAnimalID(animal);
        String UserID = getUserID(user);

        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data", MODE_PRIVATE, null);
            Cursor resultSet = mydatabase.rawQuery("Select * from Sightings where SpeciesID = '" + AnimalID + "' and UserID = '" + UserID + "'", null);
            count = resultSet.getCount();

        }
        catch(Exception e){

        }
        if(count == 0){
            int id = getResources().getIdentifier("lock2", "drawable", getPackageName());
            Drawable drawable = getResources().getDrawable(id);
            button.setImageDrawable(drawable);
            button.setTag("locked");
        }


    }

    public String getUserID(String user){
        String UserID = "0";
        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data",MODE_PRIVATE,null);
            Cursor resultSet = mydatabase.rawQuery("Select * from User where Username = '" + user + "'",null);
            resultSet.moveToFirst();
            String ID = resultSet.getString(0);
            UserID = ID;
        }
        catch (Exception e) {
            TextView textView = findViewById(R.id.textView);
            textView.setText("exception user");
        }
        return UserID;
    }

    public String getAnimalID(String animal){
        String AnimalID = "0";
        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data",MODE_PRIVATE,null);
            Cursor resultSet = mydatabase.rawQuery("Select * from Species where SpeciesName = '" + animal + "'",null);
            resultSet.moveToFirst();
            String ID = resultSet.getString(0);
            AnimalID = ID;
        }
        catch (Exception e) {
            TextView textView = findViewById(R.id.textView);
            textView.setText("exception animal");
        }
        return AnimalID;
    }




}
