package com.example.databasetest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Register extends AppCompatActivity {
    public static final String USER_NAME = "com.example.databasetest.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void onbuttonpress(View view) {
        EditText userEdit = (EditText) findViewById(R.id.user);
        String user = userEdit.getText().toString();
        EditText passEdit = (EditText) findViewById(R.id.pass);
        String pass = passEdit.getText().toString();
        EditText displayEdit = (EditText) findViewById(R.id.display);
        String display = displayEdit.getText().toString();
        String date = currentDate();


        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data",MODE_PRIVATE,null);
            mydatabase.execSQL("INSERT INTO User (Username, Password, DisplayName, DateCreated)VALUES('" + user + "', '" + pass + "', '" + display + "', '" + date + "');");
            TextView textView = findViewById(R.id.textView);
            String message = user + " added to the database with display name " + display;
            textView.setText(message);

            Intent intent = new Intent(this, Collection.class);
            intent.putExtra(USER_NAME, user);
            startActivity(intent);

        }
        catch (Exception e) {
            TextView textView = findViewById(R.id.textView);
            textView.setText("exception");
        }


    }

    public static String currentDate() {
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yy");
        // get current date time with Date()
        Date date = new Date();
        // System.out.println(dateFormat.format(date));
        // don't print it, but save it!
        return dateFormat.format(date);
    }
}
