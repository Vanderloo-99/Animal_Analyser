package com.example.databasetest;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimalInfo extends AppCompatActivity {

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_info);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String animal = bundle.getString(Collection.ANIMAL_CHOSEN);
        TextView textView = findViewById(R.id.textView);
        textView.setText(animal);
        String animalPic = animal.toLowerCase() + "2";
        int id = getResources().getIdentifier(animalPic, "drawable", getPackageName());
        Drawable drawable = getResources().getDrawable(id);
        ImageView imageView = findViewById(R.id.imageView);
        imageView.setImageDrawable(drawable);


        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        String user = pref.getString("USERNAME", null);


        String UserID = getUserID(user);
        String AnimalID= getAnimalID(animal);
        String sightingNo = getSightingNo(UserID, AnimalID);
        TextView sightingNoText = findViewById(R.id.textView2);
        sightingNoText.setText("Number of times seen: " + sightingNo);


    }

    public String getUserID(String user){
        String UserID = "0";
        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data",MODE_PRIVATE,null);
            Cursor resultSet = mydatabase.rawQuery("Select * from User where Username = '" + user + "'",null);
            resultSet.moveToFirst();
            String ID = resultSet.getString(0);
            UserID = ID;
        }
        catch (Exception e) {
            TextView textView = findViewById(R.id.textView);
            textView.setText("exception user");
        }
        return UserID;
    }

    public String getAnimalID(String animal){
        String AnimalID = "0";
        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data",MODE_PRIVATE,null);
            Cursor resultSet = mydatabase.rawQuery("Select * from Species where SpeciesName = '" + animal + "'",null);
            resultSet.moveToFirst();
            String ID = resultSet.getString(0);
            AnimalID = ID;
        }
        catch (Exception e) {
            TextView textView = findViewById(R.id.textView);
            textView.setText("exception animal");
        }
        return AnimalID;
    }

    public String getSightingNo(String UserID, String AnimalID){
        String sightingNo = "0";
        try {
            SQLiteDatabase mydatabase = openOrCreateDatabase("data", MODE_PRIVATE, null);
            Cursor resultSet = mydatabase.rawQuery("Select * from Sightings where SpeciesID = '" + AnimalID + "' and UserID = '" + UserID + "'", null);
            int count = resultSet.getCount();
            sightingNo = Integer.toString(count);
        }
        catch (Exception e) {
            TextView textView = findViewById(R.id.textView);
            textView.setText("exception sighting");
        }
        return sightingNo;
    }
}
